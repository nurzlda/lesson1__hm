package com.example.lesson1_month4

interface ItemClickListener {

    fun itemClick()
    fun itemClick2()
}