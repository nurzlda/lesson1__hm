package com.example.lesson1_month4

data class BoardModel(
    val image : String,
    val description : String,
    val button : String
)
